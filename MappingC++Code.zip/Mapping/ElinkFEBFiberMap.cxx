#include "./ElinkFEBFiberMap.h"

using namespace std;

ElinkFEBFiberMap::ElinkFEBFiberMap(){
  //Init();
  verbose = false;
}

void ElinkFEBFiberMap::SetVerbose(bool v) {
  verbose = v;
}


void ElinkFEBFiberMap::Clear() {

  ElinkLayerQuadMapping.clear();

  ElinkFEBFiberMapping.clear();

}


bool ElinkFEBFiberMap::SetElinkLayerQuadMap(int quadNum, int layerNum, int ispFEB, int l1ddc,int elink) 
{

  bool is_okay = true;
  
  //-----------------------------------------------//                                                                                                                                                     

  if ( !( quadNum >= 1 && quadNum <= 3 ) ) {
    is_okay = false;
    cout<<"Quad Num Problem "<<endl;
  }

  if ( !( layerNum >= 1 && layerNum <= 4 ) ) {
    is_okay = false;
    cout<<"Layer Num problem "<<endl;
  }

  if ( !is_okay ) {
    std::cout << "Elink-Layer-Quadruplet Mapping Failed" << std::endl;
    std::cout << " Quad" << quadNum << " Layer " << layerNum << " ispFEB " << ispFEB
              << " Elink "<< elink << std::endl;
  }
  
  else
  {
    if ( verbose ) 
    {
      std::cout << "Setting Elink Layer Quadruplet mapping: ";
      std::cout << " quad number " << quadNum;
      std::cout << " layer number " << layerNum;
      std::cout << " is pFEB " << ispFEB;
      std::cout << " Elink "<< elink << std::endl;
    } 

    ElinkLayerQuadMapping.insert(std::make_pair(elink, std::make_tuple(quadNum,layerNum,ispFEB,l1ddc)));  
				 
  }
  
  return is_okay;
    
}

bool ElinkFEBFiberMap::SetElinkFEBFiberMap(int FiberNum, double FENum,
                                           int elink) {

  bool is_okay = true;
  
  if(FENum>3.0 || FENum <1.0) is_okay=false;
  
  if(!is_okay) {
    std::cout << "Elink-FEB-Fiber Mapping Failed" << std::endl;
    std::cout << "Fiber number " << FiberNum 
              << " FE Number " << FENum
              << " Elink "<< elink << std::endl;
  }
  else{
    if(verbose) {
      std::cout << "Setting Elink FEB Fiber mapping: ";
      std::cout << " Fiber number " << FiberNum;
      std::cout << " FE number " << FENum;
      std::cout << " Elink"<< elink << std::endl;
    }

    ElinkFEBFiberMapping.insert(std::make_pair(elink, std::make_pair(FiberNum,FENum)));
    
  }

  return is_okay;

}

bool ElinkFEBFiberMap::ReturnFEBFiberNumber(int &FiberNum, double &FENum, int elink){

  bool foundNum = false;

  if(elink<0){
    cout<<"ReturnFEBFiberNumber(int &FiberNum, double &FENum, int elink): Elink cannot be a negative number "<<endl;
  }

  else{

    std::pair<int, double> fefiber_pair;

    std::map <int, std::pair<int, double> >::iterator X = ElinkFEBFiberMapping.find(elink);

    if(X != ElinkFEBFiberMapping.end() ) { 
      if ( verbose ) cout<<"ReturnFEBFiberNumber : Elink "<<elink<<" found "<<endl;  
      fefiber_pair = X->second;
      FiberNum = fefiber_pair.first;                                                                                                                 
      FENum = fefiber_pair.second;                                                                                                                                                     
      foundNum = true;                                                                                               
    }                                                                                                                         
    else{ cout<<"ReturnFEBFiberNumber: Elink not found "<<endl;}
  }
  
  return ( foundNum );
  
}

bool ElinkFEBFiberMap::ReturnLayerQuadNumber(int &quadNum, int &layerNum, int &ispFEB, int &l1ddc, int elink){

  bool foundNum = false;

  if(elink<0){
    cout<<"ReturnFEBFiberNumber(int &FiberNum, double &FENum, int elink): Elink cannot be a negative number "<<endl;
  }

  else{

    std::tuple<int, int, int, int> LayQuadpFEB_tuple;

    std::map <int, std::tuple<int, int, int, int> >::iterator X = ElinkLayerQuadMapping.find(elink);

    if(X != ElinkLayerQuadMapping.end() ) {
      if ( verbose ) cout<<"ReturnFEBFiberNumber : Elink "<<elink<<" found "<<endl;
      LayQuadpFEB_tuple = X->second;
      quadNum = get<0>(LayQuadpFEB_tuple);
      layerNum = get<1>(LayQuadpFEB_tuple);
      ispFEB = get<2>(LayQuadpFEB_tuple);
      l1ddc = get<3>(LayQuadpFEB_tuple);
      foundNum = true;
    }
    else{ cout<<"ReturnLayerQuadNumber: Elink not found "<<endl;}
  }

  return ( foundNum );

}

