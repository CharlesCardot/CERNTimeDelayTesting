#define run_cxx

#include <iostream>
#include <vector>
#include <cstring>
#include "./ElinkFEBFiberMap.h"
#include "./ElinkMapping.h"

#include <cmath>
#include <TLorentzVector.h>
#include <TVector3.h>
#include <algorithm>
//#include "Anal.h"                                                                                              
//#include <TH2.h>                                                                                              
#include <TH1F.h>
#include <TStyle.h>
#include <TCanvas.h>
#include <array>

#include <iomanip>
#include "THStack.h"
#include <math.h>

#include "TApplication.h"
#include <TSystem.h>
#include "TDquery.h"
#include <fstream>
#include <string>

using namespace std;


ElinkMapping *m_ElinkMap;
//m_ElinkMap = new ElinkMapping();

int main(){
    

    my_class test;
    
    //Fill a map with TimeDelay Mapping txt File
    test.readtxt();

    //Example Query of Map
    test.query('Q','S','1','P','2',"Pad","j72");

    return 0;
}
