#ifndef ElinkMapping_H
#define ElinkMapping_H

#include <string>

#include <iostream>
#include <sstream>
#include <fstream>

#include <iterator>

#include <vector>
#include <map>
#include <utility>

#include <TString.h>

#include "ElinkFEBFiberMap.h"

class ElinkMapping {

 public :
  ElinkMapping();
  virtual ~ElinkMapping(){};

  std::stringstream m_sx;

  std::string v11_input_xu_elinkfebfiber_file_raw, v12_input_xu_elinkfebfiber_file_raw, v21_input_xu_elinkfebfiber_file_raw, v22_input_xu_elinkfebfiber_file_raw;

  bool verbose;

  ElinkFEBFiberMap * Elink_Mapping;

  void LoadXuMapping(const char *input_raw);

  void SetVerbose(bool v);
  
  bool ReturnFEBFiberNumber(int &FiberNum, double &FENum, int elink);
  bool ReturnLayerQuadNumber(int &quadNum, int &layerNum, int &ispFEB, int &l1ddc, int elink);


};

#endif
