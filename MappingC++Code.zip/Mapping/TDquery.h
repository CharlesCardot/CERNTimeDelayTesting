#include <string>

#include <iostream>
#include <sstream>
#include <fstream>

#include <iterator>

#include <vector>
#include <map>
#include <utility>

#include <algorithm>

#include <TString.h>

#include <boost/bimap.hpp>
#include <tuple>

using namespace std;

// TDquery.h
class my_class
{
    public:
        
        map<tuple<char, char, int, char, int, std::string, std::string>, float> TDMapping;
                
        void readtxt();
        void Clear();
        float query(char Quadruplate, char Size, char Quadnum, char WedgeType, char Layer, string DetectorType, string GFZChannel);
};
