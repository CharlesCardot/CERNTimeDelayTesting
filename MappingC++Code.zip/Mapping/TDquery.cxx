#include "./TDquery.h"

#include <iostream>
#include <iterator>
#include <map>
#include <fstream>
#include <string>
#include <array>
#include <sstream>
#include <vector>
#include <tuple>
#include <stdlib.h>
using namespace std;


void my_class::readtxt()
{
    ifstream inFile("DetectorAndABTotalTimeDelaysSmallPivot.txt");
    string strOneLine;

    char Quadruplate = 'Q';
    char Size;
    char Quadnum;
    char WedgeType;
    char Layer;
    string DetectorType;
    string GFZChannel;
    float TDtemp;

    while (inFile)
    {
        getline(inFile, strOneLine);
        //cout<<strOneLine<<endl;

        vector<string> array;
        stringstream ss(strOneLine);
        string tmp;

        while(getline(ss, tmp, ' '))
        {
            array.push_back(tmp);
        }

        
        string holder = array.back();
        TDtemp = ::atof(holder.c_str());
        
        //cout<<TDtemp<<endl;   

        for(auto it = array.begin(); it != array.end(); ++it)
        {
            //cout<<"reached"<<endl;
            //cout<< (*it) << endl;
            //cout<<"reached"<<endl;
            //cout<<(*it)<<endl;
            if((*it).at(0)=='Q')
            {
                Size = (*it).at(1);
                Quadnum = (*it).at(2);
                WedgeType = (*it).at(3);
                Layer = (*it).at(4);
            }
            
            if((*it)=="Pad")
            {
                DetectorType = "Pad";
            }

            if((*it)=="String")
            {
                DetectorType = "String";
            }
            
            if((*it).at(0)=='i' || (*it).at(0)=='j')
            {
                GFZChannel = (*it);
            }
            
            TDMapping.insert(make_pair(make_tuple(Quadruplate,Size,Quadnum,WedgeType,Layer,DetectorType,GFZChannel),TDtemp));
            
        }
        inFile>>ws;
    }
    
    inFile.close();
}

float my_class::query(char Quadruplate, char Size, char Quadnum, char WedgeType, char Layer, string DetectorType, string GFZChannel)
{
    float answer;
    cout<<"Made it to Query Class"<<endl;
    auto Input = make_tuple(Quadruplate,Size,Quadnum,WedgeType,Layer,DetectorType,GFZChannel);

    auto X = TDMapping.find(Input);

    if(X != TDMapping.end())
    {
        cout<<"Time Delay for "<<Quadruplate<<Size<<Quadnum<<WedgeType<<Layer<<" "<<DetectorType<<" "<<GFZChannel<<endl;
        answer = X->second;
        cout<<answer<<endl;
        return answer;
    }
    else
    {
        cout<<"problem"<<endl;
        return 0;
    }

}


void my_class::Clear()
{
    TDMapping.clear();
}





