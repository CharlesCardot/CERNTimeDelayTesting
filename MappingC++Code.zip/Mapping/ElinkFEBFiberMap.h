#ifndef ElinkFEBFiberMap_H
#define ElinkFEBFiberMap_H

#include <string>

#include <iostream>
#include <sstream>
#include <fstream>

#include <iterator>

#include <vector>
#include <map>
#include <utility>

#include <algorithm>

#include <TString.h>

#include <boost/bimap.hpp>

class ElinkFEBFiberMap{

 public :

  ElinkFEBFiberMap();
  virtual ~ElinkFEBFiberMap(){};
  
  
  std::map< int, std::pair<int, double> > ElinkFEBFiberMapping;
  std::map< int, std::tuple<int, int, int, int> > ElinkLayerQuadMapping;
  
  std::stringstream m_sx;

  bool verbose;

  void Clear();

  void SetVerbose(bool v);
  
  bool SetElinkLayerQuadMap( int quadNum, int layerNum, int ispFEB, int l1ddc,
			  int elink);
  
  bool SetElinkFEBFiberMap( int FiberNum, double FENum, int elink);
  
  bool ReturnFEBFiberNumber( int &FiberNum, double &FENum, int elink);
  
  bool ReturnLayerQuadNumber(int &quadNum, int &layerNum, int &ispFEB, int &l1ddc, int elink);
  
  
 
  
};
#endif
  
