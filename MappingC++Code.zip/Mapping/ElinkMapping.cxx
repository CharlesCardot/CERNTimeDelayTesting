#include "./ElinkMapping.h"
#include "./ElinkFEBFiberMap.h"

using namespace std;

ElinkMapping::ElinkMapping(){

  v11_input_xu_elinkfebfiber_file_raw = "/home/patmasid/Felix_Analysis/src/ElinkFebFiberMapping/ElinkFebFiberMapping_v1_1.txt";
  v12_input_xu_elinkfebfiber_file_raw = "/home/patmasid/Felix_Analysis/src/ElinkFebFiberMapping/ElinkFebFiberMapping_v1_2.txt";
  v21_input_xu_elinkfebfiber_file_raw = "/home/patmasid/Felix_Analysis/src/ElinkFebFiberMapping/ElinkFebFiberMapping_v2_1.txt";
  v22_input_xu_elinkfebfiber_file_raw = "/home/patmasid/Felix_Analysis/src/ElinkFebFiberMapping/ElinkFebFiberMapping_v2_2.txt";

  verbose = false;
  
  Elink_Mapping = new ElinkFEBFiberMap();

  SetVerbose( verbose );


}

void ElinkMapping::SetVerbose(bool v) {
  verbose = v;

  Elink_Mapping->SetVerbose( verbose );

}

void ElinkMapping::LoadXuMapping(const char *input_raw) {
  
  if (verbose) std::cout << "Loading Adapter Board Mapping " << input_raw << std::endl;
  
  std::string line;

  std::ifstream myfile(input_raw);
  
  if ( myfile.is_open() ) {
    
    if (verbose) std::cout << "Open Elink Mapping " << input_raw << std::endl;
    
    while ( std::getline ( myfile,line ) ) {
      
      if ( line == "" ) return;
      
      std::string data_str =  line;
      
      if (verbose) std::cout << data_str << std::endl;
      
      std::istringstream iss(line);
      
      std::string L1DDC, Layer, IspFEB, Quad, Fiber, Feb, Elink1, Elink2, Elink3, Elink4;
      
      int l1ddcNum, layerNum, ispFEBNum, quadNum, fiberNum;
      //std::vector<int> elinks;
      vector<int> elinks;
      double febNum;

      elinks.resize(4);
 
      iss
	>> L1DDC >> l1ddcNum
	>> Layer >> layerNum
	>> IspFEB >> ispFEBNum
	>> Quad >> quadNum
	>> Fiber >> fiberNum
	>> Feb >> febNum
	>> Elink1 >> elinks[0]
	>> Elink2 >> elinks[1]
	>> Elink3 >> elinks[2]
	>> Elink4 >> elinks[3];
		      
      //cout<<" L1DDC " <<l1ddcNum << " Layer " << layerNum << " IspFEB " << ispFEBNum << " Quad " << quadNum << " Fiber " << fiberNum << " Feb " << febNum << " Elink " << elink  << endl;
      
      bool okay_1, okay_2;
      
      for(int ii=0; ii<elinks.size(); ii++){
	okay_1 = Elink_Mapping->SetElinkFEBFiberMap(fiberNum, febNum, elinks[ii]);
	okay_2 = Elink_Mapping->SetElinkLayerQuadMap(quadNum, layerNum, ispFEBNum, l1ddcNum,elinks[ii]);
      }
      if ( !okay_1 ) {
	std::cout << "Error:  ElinkFEBFiber Mapping line entry not parsed correctly" << std::endl;
	std::cout << "\t " << line << std::endl;
      }
      else if(!okay_2) {
	std::cout << "Error:  ElinkLayerQuad Mapping line entry not parsed correctly" << std::endl;
	std::cout << "\t " << line << std::endl;
      }
    
  
    }
  }
}


bool ElinkMapping::ReturnFEBFiberNumber(int &FiberNum, double &FENum, int elink){

  double v_FENum = -1.0;
  int v_FiberNum = -1;
  bool foundNum=false;

  foundNum = Elink_Mapping->ReturnFEBFiberNumber(v_FiberNum, v_FENum, elink);
 
  if(foundNum){
    //cout<<" Fiber "<<v_FiberNum<<" FEB "<<v_FENum<<" elink "<<elink<<endl;
    FiberNum = v_FiberNum;                                                                                                                                           
    FENum = v_FENum;
  }
  return foundNum;

}

bool ElinkMapping::ReturnLayerQuadNumber(int &quadNum, int &layerNum, int &ispFEB, int &l1ddc, int elink){

  int v_quadNum = -1;
  int v_layerNum = -1;
  int v_ispFEB = -1;
  int v_l1ddc = -1;
  
  if(! (Elink_Mapping->ReturnLayerQuadNumber(v_quadNum, v_layerNum, v_ispFEB, v_l1ddc, elink)) ){
    cout<< "Elink not found"<<endl;
    return 0;
  }
  else{
    
    quadNum = v_quadNum;
    layerNum = v_layerNum;
    ispFEB = v_ispFEB;
    l1ddc = v_l1ddc;
    return 1;
  }

}

